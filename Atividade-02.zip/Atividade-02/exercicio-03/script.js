function azul() {
    document.body.style.backgroundColor ="blue";
    Text = "O fundo da pagina foi alterado para azul.";
    document.getElementById("conteudo").innerHTML = Text
}

function verde() {
    document.body.style.backgroundColor ="green";
    Text = "O fundo da pagina foi alterado para verde.";
    document.getElementById("conteudo").innerHTML = Text
}

function vermelho() {
    document.body.style.backgroundColor ="red";
    Text = "O fundo da pagina foi alterado para vermelho.";
    document.getElementById("conteudo").innerHTML = Text
}