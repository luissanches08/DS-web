function imagem1() {
    document.getElementById("foto").setAttribute("src", "imagem-ronaldo01.jpeg");
}

function imagem2() {
    document.getElementById("foto").setAttribute("src", "imagem-ronaldo02.jpg");
}

function adconsole() {
    console.log (document.getElementById("foto").getAttribute("src"))
}

